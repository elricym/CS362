package cs362;

import java.io.Serializable;

public abstract class Label implements Serializable {

	public abstract String toString();

	public abstract double getValue();
}
